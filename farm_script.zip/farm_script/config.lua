Config = {}

Config.Farms = {
    [1] = {
        id = 1,
        name = "Small Farm",
        slots = 10,
        price = 1000000,
        enterCoords = vector3(2220.55, 5576.35, 53.73),
        tractorCoords = vector4(2225.0, 5580.0, 53.73, 0.0),
        storeCoords = vector3(2218.0, 5570.0, 53.73),
        landCoords = {
            vector3(2230.0, 5590.0, 53.73),
            vector3(2233.0, 5590.0, 53.73),
            vector3(2236.0, 5590.0, 53.73),
            vector3(2239.0, 5590.0, 53.73),
            vector3(2242.0, 5590.0, 53.73),
            vector3(2230.0, 5594.0, 53.73),
            vector3(2233.0, 5594.0, 53.73),
            vector3(2236.0, 5594.0, 53.73),
            vector3(2239.0, 5594.0, 53.73),
            vector3(2242.0, 5594.0, 53.73),
        },
        blipSprite = 140,
        blipColor = 2,
    },
    [2] = {
        id = 2,
        name = "Small-Medium Farm",
        slots = 15,
        price = 5000000,
        enterCoords = vector3(2120.55, 5476.35, 53.73),
        tractorCoords = vector4(2125.0, 5480.0, 53.73, 0.0),
        storeCoords = vector3(2118.0, 5470.0, 53.73),
        landCoords = {
            vector3(2130.0, 5490.0, 53.73),
            vector3(2133.0, 5490.0, 53.73),
            vector3(2136.0, 5490.0, 53.73),
            vector3(2139.0, 5490.0, 53.73),
            vector3(2142.0, 5490.0, 53.73),
            vector3(2130.0, 5494.0, 53.73),
            vector3(2133.0, 5494.0, 53.73),
            vector3(2136.0, 5494.0, 53.73),
            vector3(2139.0, 5494.0, 53.73),
            vector3(2142.0, 5494.0, 53.73),
            vector3(2130.0, 5498.0, 53.73),
            vector3(2133.0, 5498.0, 53.73),
            vector3(2136.0, 5498.0, 53.73),
            vector3(2139.0, 5498.0, 53.73),
            vector3(2142.0, 5498.0, 53.73),
        },
        blipSprite = 140,
        blipColor = 3,
    },
    [3] = {
        id = 3,
        name = "Medium Farm",
        slots = 20,
        price = 10000000,
        enterCoords = vector3(2020.55, 5376.35, 53.73),
        tractorCoords = vector4(2025.0, 5380.0, 53.73, 0.0),
        storeCoords = vector3(2018.0, 5370.0, 53.73),
        landCoords = (function()
            local coords = {}
            for i = 0, 3 do
                for j = 0, 4 do
                    table.insert(coords, vector3(2030.0 + j*3, 5390.0 + i*4, 53.73))
                end
            end
            return coords
        end)(),
        blipSprite = 140,
        blipColor = 4,
    },
    [4] = {
        id = 4,
        name = "Large Farm",
        slots = 30,
        price = 30000000,
        enterCoords = vector3(1920.55, 5276.35, 53.73),
        tractorCoords = vector4(1925.0, 5280.0, 53.73, 0.0),
        storeCoords = vector3(1918.0, 5270.0, 53.73),
        landCoords = (function()
            local coords = {}
            for i = 0, 4 do
                for j = 0, 5 do
                    table.insert(coords, vector3(1930.0 + j*3, 5290.0 + i*4, 53.73))
                end
            end
            return coords
        end)(),
        blipSprite = 140,
        blipColor = 5,
    },
    [5] = {
        id = 5,
        name = "Extra Large Farm",
        slots = 40,
        price = 40000000,
        enterCoords = vector3(1820.55, 5176.35, 53.73),
        tractorCoords = vector4(1825.0, 5180.0, 53.73, 0.0),
        storeCoords = vector3(1818.0, 5170.0, 53.73),
        landCoords = (function()
            local coords = {}
            for i = 0, 4 do
                for j = 0, 7 do
                    table.insert(coords, vector3(1830.0 + j*3, 5190.0 + i*4, 53.73))
                end
            end
            return coords
        end)(),
        blipSprite = 140,
        blipColor = 6,
    },
    [6] = {
        id = 6,
        name = "Massive Farm",
        slots = 50,
        price = 50000000,
        enterCoords = vector3(1720.55, 5076.35, 53.73),
        tractorCoords = vector4(1725.0, 5080.0, 53.73, 0.0),
        storeCoords = vector3(1718.0, 5070.0, 53.73),
        landCoords = (function()
            local coords = {}
            for i = 0, 4 do
                for j = 0, 9 do
                    table.insert(coords, vector3(1730.0 + j*3, 5090.0 + i*4, 53.73))
                end
            end
            return coords
        end)(),
        blipSprite = 140,
        blipColor = 7,
    },
}

Config.Plants = {
    ["wheat"] = {
        label = "Wheat",
        seed_item = "wheat_seed",
        harvest_item = "wheat",
        harvest_amount = {min = 3, max = 6},
        grow_time = 15 * 60, 
        expire_time = 30 * 60 * 60, 
        prop = "prop_plant_fern_02",
        prop_grown = "prop_bush_neat_02",
        water_needed = true,
    },
    ["corn"] = {
        label = "Corn",
        seed_item = "corn_seed",
        harvest_item = "corn",
        harvest_amount = {min = 4, max = 8},
        grow_time = 40 * 60,
        expire_time = 30 * 60 * 60,
        prop = "prop_plant_fern_01",
        prop_grown = "prop_plant_fern_03",
        water_needed = true,
    },
    ["grape"] = {
        label = "Grape",
        seed_item = "grape_seed",
        harvest_item = "grape",
        harvest_amount = {min = 5, max = 10},
        grow_time = 20 * 60, 
        expire_time = 30 * 60 * 60,
        prop = "prop_plant_fern_01",
        prop_grown = "prop_bush_lush_02",
        water_needed = true,
    },
    ["potato"] = {
        label = "Potato",
        seed_item = "potato_seed",
        harvest_item = "potato",
        harvest_amount = {min = 3, max = 7},
        grow_time = 25 * 60,
        expire_time = 30 * 60 * 60,
        prop = "prop_plant_fern_02",
        prop_grown = "prop_plant_fern_02",
        water_needed = true,
    },
    ["tomato"] = {
        label = "Tomato",
        seed_item = "tomato_seed",
        harvest_item = "tomato",
        harvest_amount = {min = 4, max = 9},
        grow_time = 30 * 60, 
        expire_time = 30 * 60 * 60,
        prop = "prop_plant_fern_01",
        prop_grown = "prop_bush_lush_01",
        water_needed = true,
    },
    ["cannabis"] = {
        label = "Industrial Hemp",
        seed_item = "cannabis_seed",
        harvest_item = "cannabis",
        harvest_amount = {min = 2, max = 5},
        grow_time = 60 * 60, 
        expire_time = 30 * 60 * 60,
        prop = "prop_weed_01",
        prop_grown = "prop_weed_02",
        water_needed = true,
    },
}

Config.TractorModel = "TractorFR"

Config.LandKey = 1000

Config.WateringTime = 5000  
Config.HarvestTime = 5000   
Config.UprootTime = 5000    

Config.InteractionDistance = 3.0
Config.NotifyDistance = 10.0

Config.GrowthColors = {
    [0]  = {r=255, g=100, b=100},
    [25] = {r=255, g=200, b=0},    
    [50] = {r=200, g=255, b=0},    
    [75] = {r=100, g=255, b=100}, 
    [100]= {r=0,   g=255, b=50}, 
}