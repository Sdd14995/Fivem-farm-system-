'use strict';

let state = {
    farmId: null,
    farmName: '',
    farmPrice: 0,
    farmSlots: 0,
    hasLand: false,
    landData: null,
    storage: {},
    plants: {},
    farms: [],
    selectedPlant: null,
    activePlants: {},
    usedSlots: 0,
    takeItem: null,
    takeMax: 0,
};

const plantEmojis = {
    wheat: '🌾', corn: '🌽', grape: '🍇',
    potato: '🥔', tomato: '🍅', cannabis: '🌿',
};

const plantLabels = {
    wheat: 'Wheat', corn: 'Corn', grape: 'Grape',
    potato: 'Potato', tomato: 'Tomato', cannabis: 'Industrial Hemp',
};

const itemEmojis = {
    wheat: '🌾', corn: '🌽', grape: '🍇',
    potato: '🥔', tomato: '🍅', cannabis: '🌿',
    wheat_seed: '🫘', corn_seed: '🫘', grape_seed: '🫘',
};

// =============================================
// NUI MESSAGE LISTENER
// =============================================
window.addEventListener('message', function(event) {
    const data = event.data;

    switch (data.type) {
        case 'setConfig':
            state.plants = data.plants || {};
            state.farms = data.farms || [];
            buildPlantsGrid();
            break;

        case 'openMenu':
            openFarmMenu(data);
            break;

        case 'openFarm':
            handleEnterFarm(data);
            break;

        case 'landBought':
            state.hasLand = true;
            state.landData = data.land;
            showView('hasLandView');
            showNotif('Land purchased! Default PIN: ' + data.land.password, 'success');
            break;

        case 'updateStorage':
            state.storage = data.storage || {};
            renderStorage();
            break;

        case 'storageData':
            state.storage = data.storage || {};
            renderStorage();
            break;

        case 'syncPlants':
            state.activePlants = data || {};
            updateSlotsInfo();
            break;

        case 'passwordChanged':
            if (state.landData) state.landData.password = data.password;
            showNotif('PIN updated successfully!', 'success');
            break;

        case 'myLandData':
            if (data.land) {
                state.hasLand = true;
                state.landData = data.land;
                showView('hasLandView');
            } else {
                state.hasLand = false;
                state.landData = null;
                showView('noLandView');
            }
            break;

        case 'progressBar':
            showProgressBar(data.label, data.duration);
            break;
    }
});

function openFarmMenu(data) {
    state.farmId = data.farmId;
    state.farmName = data.farmName;
    state.farmPrice = data.farmPrice;
    state.farmSlots = data.farmSlots;
    if (data.plants) state.plants = data.plants;

    document.getElementById('farmTitle').textContent = data.farmName;
    document.getElementById('farmSubtitle').textContent = 'Smart Farming System';
    document.getElementById('landPriceText').textContent =
        'Land Price: $' + formatMoney(data.farmPrice);
    document.getElementById('landSlotsText').textContent =
        'Planting Slots: ' + data.farmSlots;
    document.getElementById('slotsTotal').textContent = data.farmSlots;

    buildPlantsGrid();
    switchTab('main');
    show('farmMenu');
}

function handleEnterFarm(data) {
    state.hasLand = true;
    state.landData = data.land;
    state.storage = data.storage || {};

    if (data.plants) {
        data.plants.forEach(p => {
            state.activePlants[p.id] = p;
        });
    }

    closeMenu();
    updateSlotsInfo();
}

function closeMenu() {
    hide('farmMenu');
    fetchNUI('closeMenu', {});
}

function switchTab(tab) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));

    show('content-' + tab);
    document.getElementById('tab-' + tab).classList.add('active');

    if (tab === 'storage') {
        fetchNUI('getStorage', {});
    }
    if (tab === 'plant') {
        updateSlotsInfo();
    }
}

function showView(viewId) {
    hide('noLandView');
    hide('hasLandView');
    show(viewId);
}

function buyLand() {
    if (!confirm('Are you sure you want to purchase this land? Price: $' + formatMoney(state.farmPrice))) return;
    fetchNUI('buyLand', { farmId: state.farmId });
}

function enterFarm() {
    const pass = document.getElementById('enterPassword').value.trim();
    if (!pass) {
        showNotif('Please enter your PIN!', 'warning');
        return;
    }
    fetchNUI('enterFarm', { farmId: state.farmId, password: pass });
}

function changePassword() {
    const oldPass = document.getElementById('oldPassword').value.trim();
    const newPass = document.getElementById('newPassword').value.trim();
    const confirmPass = document.getElementById('confirmPassword').value.trim();

    if (!oldPass || !newPass || !confirmPass) {
        showNotif('Please fill in all fields!', 'warning');
        return;
    }
    if (newPass.length < 4) {
        showNotif('New PIN must be at least 4 characters!', 'warning');
        return;
    }
    if (newPass !== confirmPass) {
        showNotif('New PIN and confirmation do not match!', 'error');
        return;
    }

    fetchNUI('changePassword', { oldPass, newPass });

    document.getElementById('oldPassword').value = '';
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmPassword').value = '';
}

function refreshStorage() {
    fetchNUI('getStorage', {});
}

function renderStorage() {
    const grid = document.getElementById('storageGrid');
    const items = Object.entries(state.storage).filter(([k, v]) => v > 0);

    if (items.length === 0) {
        grid.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">📭</div>
                <div>Storage is empty</div>
            </div>`;
        return;
    }

    grid.innerHTML = items.map(([item, count]) => `
        <div class="storage-item" onclick="openTakeModal('${item}', ${count})">
            <div class="storage-item-icon">${itemEmojis[item] || '📦'}</div>
            <div class="storage-item-name">${getItemLabel(item)}</div>
            <div class="storage-item-count">${count}</div>
        </div>
    `).join('');
}

function getItemLabel(item) {
    const labels = {
        wheat: 'Wheat', corn: 'Corn', grape: 'Grape',
        potato: 'Potato', tomato: 'Tomato', cannabis: 'Industrial Hemp',
    };
    return labels[item] || item;
}

function openTakeModal(item, max) {
    state.takeItem = item;
    state.takeMax = max;
    document.getElementById('takeModalItem').textContent =
        'Item: ' + getItemLabel(item) + ' | Amount: ' + max;
    document.getElementById('takeAmount').value = 1;
    document.getElementById('takeAmount').max = max;
    show('takeModal');
}

function closeTakeModal() {
    hide('takeModal');
    state.takeItem = null;
}

function confirmTake() {
    const amount = parseInt(document.getElementById('takeAmount').value);
    if (!amount || amount < 1 || amount > state.takeMax) {
        showNotif('Invalid amount!', 'warning');
        return;
    }
    fetchNUI('takeFromStorage', { item: state.takeItem, amount });
    closeTakeModal();
}

function buildPlantsGrid() {
    const grid = document.getElementById('plantsGrid');
    const growTimes = {
        wheat: '15m', corn: '40m', grape: '20m',
        potato: '25m', tomato: '30m', cannabis: '60m',
    };

    const plantKeys = Object.keys(plantLabels);
    grid.innerHTML = plantKeys.map(key => `
        <div class="plant-card" id="plant-${key}" onclick="selectPlant('${key}')">
            <div class="plant-emoji">${plantEmojis[key] || '🌱'}</div>
            <div class="plant-name">${plantLabels[key]}</div>
            <div class="plant-grow-time">⏱ ${growTimes[key] || '-'}</div>
        </div>
    `).join('');

    if (!document.getElementById('plantBtn')) {
        const btn = document.createElement('button');
        btn.id = 'plantBtn';
        btn.className = 'btn btn-green big-btn';
        btn.style.marginTop = '8px';
        btn.onclick = plantSelected;
        btn.textContent = '🌱 Plant Selected Seed';
        document.getElementById('content-plant').appendChild(btn);
    }
}

function selectPlant(type) {
    document.querySelectorAll('.plant-card').forEach(el => el.classList.remove('selected'));
    document.getElementById('plant-' + type).classList.add('selected');
    state.selectedPlant = type;
}

function plantSelected() {
    if (!state.selectedPlant) {
        showNotif('Please select a plant first!', 'warning');
        return;
    }
    if (!state.landData) {
        showNotif('Please enter the farm first!', 'warning');
        return;
    }

    fetchNUI('plantSeed', { plantType: state.selectedPlant }, function(result) {
        if (result.success) {
            showNotif('Seed planted! Slot ' + result.slotIndex, 'success');
            state.usedSlots++;
            updateSlotsInfo();
        } else {
            showNotif(result.msg || 'Planting failed!', 'error');
        }
    });
}

function updateSlotsInfo() {
    if (!state.landData) return;

    const landId = state.landData.id;
    let used = 0;
    Object.values(state.activePlants).forEach(p => {
        if (p.land_id === landId) used++;
    });
    state.usedSlots = used;

    document.getElementById('slotsUsed').textContent = used;
    const total = state.landData.slot_count || state.farmSlots;
    document.getElementById('slotsTotal').textContent = total;
    const pct = total > 0 ? (used / total * 100) : 0;
    document.getElementById('slotsFill').style.width = pct + '%';
}

let progressInterval = null;

function showProgressBar(label, duration) {
    const container = document.getElementById('progressContainer');
    const fill = document.getElementById('progressFill');
    const labelEl = document.getElementById('progressLabel');

    container.classList.remove('hidden');
    labelEl.textContent = label;
    fill.style.width = '0%';

    if (progressInterval) clearInterval(progressInterval);

    const steps = 50;
    const stepTime = duration / steps;
    let current = 0;

    progressInterval = setInterval(() => {
        current++;
        fill.style.width = (current / steps * 100) + '%';
        if (current >= steps) {
            clearInterval(progressInterval);
            setTimeout(() => container.classList.add('hidden'), 400);
        }
    }, stepTime);
}

function showNotif(msg, type = 'info') {
    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
    const container = document.getElementById('notificationContainer');
    const notif = document.createElement('div');
    notif.className = 'notification ' + type;
    notif.innerHTML = `<span>${icons[type] || 'ℹ️'}</span><span>${msg}</span>`;
    container.appendChild(notif);

    setTimeout(() => {
        notif.style.opacity = '0';
        notif.style.transform = 'translateY(-10px)';
        notif.style.transition = 'all 0.3s';
        setTimeout(() => notif.remove(), 300);
    }, 3500);
}

function show(id) { document.getElementById(id).classList.remove('hidden'); }
function hide(id) { document.getElementById(id).classList.add('hidden'); }

function formatMoney(amount) {
    return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function fetchNUI(endpoint, data, cb) {
    fetch(`https://${GetParentResourceName()}/${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }).then(r => r.json()).then(result => {
        if (cb) cb(result);
    }).catch(() => {
        if (cb) cb({});
    });
}

function GetParentResourceName() {
    return 'farm_script';
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        if (!document.getElementById('takeModal').classList.contains('hidden')) {
            closeTakeModal();
        } else if (!document.getElementById('farmMenu').classList.contains('hidden')) {
            closeMenu();
        }
    }
});