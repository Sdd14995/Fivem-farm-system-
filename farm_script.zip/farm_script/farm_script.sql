CREATE TABLE IF NOT EXISTS `farm_lands` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `identifier` VARCHAR(60) NOT NULL,
    `farm_id` INT NOT NULL,
    `slot_count` INT NOT NULL,
    `password` VARCHAR(64) NOT NULL DEFAULT '',
    `storage` LONGTEXT NOT NULL DEFAULT '{}',
    `purchased_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_identifier` (`identifier`),
    INDEX `idx_farm_id` (`farm_id`),
    UNIQUE KEY `unique_owner_farm` (`identifier`, `farm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `farm_plants` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `land_id` INT NOT NULL,
    `slot_index` INT NOT NULL,
    `plant_type` VARCHAR(32) NOT NULL,
    `planted_at` BIGINT NOT NULL,
    `watered` TINYINT(1) NOT NULL DEFAULT 0,
    `watered_at` BIGINT DEFAULT NULL,
    `grow_progress` FLOAT NOT NULL DEFAULT 0.0,
    `harvested` TINYINT(1) NOT NULL DEFAULT 0,
    `coords_x` FLOAT NOT NULL,
    `coords_y` FLOAT NOT NULL,
    `coords_z` FLOAT NOT NULL,
    INDEX `idx_land_id` (`land_id`),
    UNIQUE KEY `unique_slot` (`land_id`, `slot_index`),
    FOREIGN KEY (`land_id`) REFERENCES `farm_lands`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
