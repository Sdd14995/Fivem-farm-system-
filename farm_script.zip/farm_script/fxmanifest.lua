fx_version 'cerulean'
game 'gta5'

author 'FarmScript'
description 'Advanced Farm System for EssentialMode'
version '1.0.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua',
    'client/ui.lua',
    'client/zones.lua',
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    'server/main.lua',
    'server/database.lua',
    'server/plants.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/css/style.css',
    'html/js/app.js',
}

dependency 'mysql-async'
