local activePlants = {}

Citizen.CreateThread(function()
    Citizen.Wait(2000)
    LoadAllPlants()
end)

function LoadAllPlants()
    MySQL.Async.fetchAll(
        "SELECT fp.*, fl.farm_id FROM farm_plants fp JOIN farm_lands fl ON fp.land_id = fl.id WHERE fp.harvested = 0",
        {},
        function(result)
            activePlants = {}
            if result then
                for _, plant in ipairs(result) do
                    activePlants[plant.id] = {
                        id = plant.id,
                        land_id = plant.land_id,
                        farm_id = plant.farm_id,
                        slot_index = plant.slot_index,
                        plant_type = plant.plant_type,
                        planted_at = plant.planted_at,
                        watered = plant.watered == 1,
                        watered_at = plant.watered_at,
                        grow_progress = plant.grow_progress,
                        coords = {x = plant.coords_x, y = plant.coords_y, z = plant.coords_z},
                    }
                end
            end
            print("^2[FarmScript]^7 Loaded " .. #(result or {}) .. " active plants.")
            TriggerClientEvent('farm:syncPlants', -1, activePlants)
        end
    )
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(60000)
        UpdatePlantGrowth()
        DeleteExpiredPlants(nil)
    end
end)

function UpdatePlantGrowth()
    local now = os.time()
    local updated = {}

    for plantId, plant in pairs(activePlants) do
        if not plant.watered then goto continue end

        local plantConfig = Config.Plants[plant.plant_type]
        if not plantConfig then goto continue end

        local growStart = plant.watered_at or plant.planted_at
        local elapsed = now - growStart
        local progress = math.min(100.0, (elapsed / plantConfig.grow_time) * 100.0)

        if math.abs(progress - plant.grow_progress) >= 1.0 then
            plant.grow_progress = progress
            UpdatePlantProgress(plantId, progress, nil)
            table.insert(updated, {id = plantId, progress = progress})
        end

        ::continue::
    end

    if #updated > 0 then
        TriggerClientEvent('farm:updateGrowth', -1, updated)
    end
end

AddEventHandler('playerJoining', function()
    local src = source
    Citizen.Wait(3000)
    TriggerClientEvent('farm:syncPlants', src, activePlants)
end)

RegisterNetEvent('farm:plantSeed')
AddEventHandler('farm:plantSeed', function(landId, slotIndex, plantType, coords)
    local src = source

    if not Config.Plants[plantType] then
        TriggerClientEvent('farm:notify', src, "Invalid plant type!", "error")
        return
    end

    TriggerEvent('essentialmode:getPlayerData', src, function(xPlayer)
        if not xPlayer then return end

        PlantSeed(landId, slotIndex, plantType, coords, function(plantId)
            if plantId then
                local plantData = {
                    id = plantId,
                    land_id = landId,
                    slot_index = slotIndex,
                    plant_type = plantType,
                    planted_at = os.time(),
                    watered = false,
                    grow_progress = 0.0,
                    coords = coords,
                }
                activePlants[plantId] = plantData

                TriggerClientEvent('farm:plantedSeed', -1, plantData)
                TriggerClientEvent('farm:notify', src, Config.Plants[plantType].label .. " has been planted!", "success")
            else
                TriggerClientEvent('farm:notify', src, "Failed to plant seed!", "error")
            end
        end)
    end)
end)

RegisterNetEvent('farm:waterPlant')
AddEventHandler('farm:waterPlant', function(plantId)
    local src = source

    local plant = activePlants[plantId]
    if not plant then
        TriggerClientEvent('farm:notify', src, "Plant not found!", "error")
        return
    end

    if plant.watered then
        TriggerClientEvent('farm:notify', src, "This plant has already been watered!", "warning")
        return
    end

    WaterPlant(plantId, function(success)
        if success then
            activePlants[plantId].watered = true
            activePlants[plantId].watered_at = os.time()
            TriggerClientEvent('farm:plantWatered', -1, plantId, os.time())
            TriggerClientEvent('farm:notify', src, "Plant watered! Growth started.", "success")
        else
            TriggerClientEvent('farm:notify', src, "Failed to water the plant!", "error")
        end
    end)
end)

RegisterNetEvent('farm:harvestPlant')
AddEventHandler('farm:harvestPlant', function(plantId)
    local src = source

    local plant = activePlants[plantId]
    if not plant then
        TriggerClientEvent('farm:notify', src, "Plant not found!", "error")
        return
    end

    if plant.grow_progress < 100.0 then
        TriggerClientEvent('farm:notify', src, "The plant is not ready for harvest yet!", "warning")
        return
    end

    local plantConfig = Config.Plants[plant.plant_type]
    local amount = math.random(plantConfig.harvest_amount.min, plantConfig.harvest_amount.max)

    HarvestPlant(plantId, function(success)
        if success then
            AddToStorage(plant.land_id, plantConfig.harvest_item, amount, function(storageSuccess, newStorage)
                activePlants[plantId] = nil
                TriggerClientEvent('farm:plantHarvested', -1, plantId)
                TriggerClientEvent('farm:notify', src, amount .. " " .. plantConfig.label .. "(s) added to farm storage!", "success")
                TriggerClientEvent('farm:updateStorage', src, newStorage)
            end)
        else
            TriggerClientEvent('farm:notify', src, "Harvest failed!", "error")
        end
    end)
end)

RegisterNetEvent('farm:uprootPlant')
AddEventHandler('farm:uprootPlant', function(plantId)
    local src = source

    local plant = activePlants[plantId]
    if not plant then
        TriggerClientEvent('farm:notify', src, "Plant not found!", "error")
        return
    end

    UprootPlant(plantId, function(success)
        if success then
            activePlants[plantId] = nil
            TriggerClientEvent('farm:plantUprooted', -1, plantId)
            TriggerClientEvent('farm:notify', src, "Plant removed.", "info")
        else
            TriggerClientEvent('farm:notify', src, "Failed to remove the plant!", "error")
        end
    end)
end)

RegisterNetEvent('farm:requestPlants')
AddEventHandler('farm:requestPlants', function()
    local src = source
    TriggerClientEvent('farm:syncPlants', src, activePlants)
end)