Citizen.CreateThread(function()
    MySQL.Async.execute([[
        CREATE TABLE IF NOT EXISTS `farm_lands` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `identifier` VARCHAR(60) NOT NULL,
            `farm_id` INT NOT NULL,
            `slot_count` INT NOT NULL,
            `password` VARCHAR(64) NOT NULL DEFAULT '',
            `storage` LONGTEXT NOT NULL DEFAULT '{}',
            `purchased_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_identifier` (`identifier`),
            INDEX `idx_farm_id` (`farm_id`),
            UNIQUE KEY `unique_owner_farm` (`identifier`, `farm_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ]], {}, function() end)

    MySQL.Async.execute([[
        CREATE TABLE IF NOT EXISTS `farm_plants` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `land_id` INT NOT NULL,
            `slot_index` INT NOT NULL,
            `plant_type` VARCHAR(32) NOT NULL,
            `planted_at` BIGINT NOT NULL,
            `watered` TINYINT(1) NOT NULL DEFAULT 0,
            `watered_at` BIGINT DEFAULT NULL,
            `grow_progress` FLOAT NOT NULL DEFAULT 0.0,
            `harvested` TINYINT(1) NOT NULL DEFAULT 0,
            `coords_x` FLOAT NOT NULL,
            `coords_y` FLOAT NOT NULL,
            `coords_z` FLOAT NOT NULL,
            INDEX `idx_land_id` (`land_id`),
            UNIQUE KEY `unique_slot` (`land_id`, `slot_index`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ]], {}, function() end)

    print("^2[FarmScript]^7 Database tables verified.")
end)

function GetPlayerLand(identifier, farmId, cb)
    MySQL.Async.fetchAll(
        "SELECT * FROM farm_lands WHERE identifier = @id AND farm_id = @farm",
        {['@id'] = identifier, ['@farm'] = farmId},
        function(result)
            if result and #result > 0 then
                cb(result[1])
            else
                cb(nil)
            end
        end
    )
end

function GetAllPlayerLands(identifier, cb)
    MySQL.Async.fetchAll(
        "SELECT * FROM farm_lands WHERE identifier = @id",
        {['@id'] = identifier},
        function(result)
            cb(result or {})
        end
    )
end

function BuyLand(identifier, farmId, slotCount, password, cb)
    MySQL.Async.execute(
        "INSERT INTO farm_lands (identifier, farm_id, slot_count, password, storage) VALUES (@id, @farm, @slots, @pass, '{}')",
        {['@id'] = identifier, ['@farm'] = farmId, ['@slots'] = slotCount, ['@pass'] = password},
        function(rowsChanged)
            if rowsChanged > 0 then
                MySQL.Async.fetchScalar(
                    "SELECT id FROM farm_lands WHERE identifier = @id AND farm_id = @farm",
                    {['@id'] = identifier, ['@farm'] = farmId},
                    function(landId)
                        cb(landId)
                    end
                )
            else
                cb(nil)
            end
        end
    )
end

function UpdateLandPassword(landId, newPassword, cb)
    MySQL.Async.execute(
        "UPDATE farm_lands SET password = @pass WHERE id = @id",
        {['@pass'] = newPassword, ['@id'] = landId},
        function(rows)
            cb(rows > 0)
        end
    )
end

function GetLandPlants(landId, cb)
    MySQL.Async.fetchAll(
        "SELECT * FROM farm_plants WHERE land_id = @lid",
        {['@lid'] = landId},
        function(result)
            cb(result or {})
        end
    )
end

function PlantSeed(landId, slotIndex, plantType, coords, cb)
    local now = os.time()
    MySQL.Async.execute(
        "INSERT INTO farm_plants (land_id, slot_index, plant_type, planted_at, watered, grow_progress, coords_x, coords_y, coords_z) VALUES (@lid, @slot, @type, @now, 0, 0.0, @x, @y, @z)",
        {
            ['@lid'] = landId,
            ['@slot'] = slotIndex,
            ['@type'] = plantType,
            ['@now'] = now,
            ['@x'] = coords.x,
            ['@y'] = coords.y,
            ['@z'] = coords.z
        },
        function(rows)
            if rows > 0 then
                MySQL.Async.fetchScalar(
                    "SELECT id FROM farm_plants WHERE land_id = @lid AND slot_index = @slot",
                    {['@lid'] = landId, ['@slot'] = slotIndex},
                    function(plantId)
                        cb(plantId)
                    end
                )
            else
                cb(nil)
            end
        end
    )
end

function WaterPlant(plantId, cb)
    local now = os.time()
    MySQL.Async.execute(
        "UPDATE farm_plants SET watered = 1, watered_at = @now WHERE id = @id",
        {['@now'] = now, ['@id'] = plantId},
        function(rows)
            cb(rows > 0)
        end
    )
end

function UpdatePlantProgress(plantId, progress, cb)
    MySQL.Async.execute(
        "UPDATE farm_plants SET grow_progress = @prog WHERE id = @id",
        {['@prog'] = progress, ['@id'] = plantId},
        function(rows)
            if cb then cb(rows > 0) end
        end
    )
end

function HarvestPlant(plantId, cb)
    MySQL.Async.execute(
        "UPDATE farm_plants SET harvested = 1 WHERE id = @id",
        {['@id'] = plantId},
        function(rows)
            cb(rows > 0)
        end
    )
end

function UprootPlant(plantId, cb)
    MySQL.Async.execute(
        "DELETE FROM farm_plants WHERE id = @id",
        {['@id'] = plantId},
        function(rows)
            cb(rows > 0)
        end
    )
end

function DeleteExpiredPlants(cb)
    local expireTime = os.time() - (30 * 60 * 60)
    MySQL.Async.execute(
        "DELETE FROM farm_plants WHERE planted_at < @expire AND harvested = 0",
        {['@expire'] = expireTime},
        function(rows)
            if cb then cb(rows) end
            if rows > 0 then
                print("^3[FarmScript]^7 Deleted " .. rows .. " expired plants.")
            end
        end
    )
end

function GetLandStorage(landId, cb)
    MySQL.Async.fetchScalar(
        "SELECT storage FROM farm_lands WHERE id = @id",
        {['@id'] = landId},
        function(result)
            if result then
                local ok, data = pcall(json.decode, result)
                cb(ok and data or {})
            else
                cb({})
            end
        end
    )
end

function UpdateLandStorage(landId, storage, cb)
    MySQL.Async.execute(
        "UPDATE farm_lands SET storage = @storage WHERE id = @id",
        {['@storage'] = json.encode(storage), ['@id'] = landId},
        function(rows)
            if cb then cb(rows > 0) end
        end
    )
end

function AddToStorage(landId, item, amount, cb)
    GetLandStorage(landId, function(storage)
        storage[item] = (storage[item] or 0) + amount
        UpdateLandStorage(landId, storage, function(success)
            cb(success, storage)
        end)
    end)
end
