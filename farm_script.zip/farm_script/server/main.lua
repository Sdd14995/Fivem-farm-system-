RegisterNetEvent('farm:buyLand')
AddEventHandler('farm:buyLand', function(farmId)
    local src = source
    local identifier = GetPlayerIdentifier(src, 0)

    local farmConfig = Config.Farms[farmId]
    if not farmConfig then
        TriggerClientEvent('farm:notify', src, "Farm not found!", "error")
        return
    end

    GetPlayerLand(identifier, farmId, function(existingLand)
        if existingLand then
            TriggerClientEvent('farm:notify', src, "You already own land in this farm!", "warning")
            return
        end

        TriggerEvent('essentialmode:getPlayerData', src, function(xPlayer)
            if not xPlayer then return end

            local playerMoney = xPlayer.get('money') or 0
            if playerMoney < farmConfig.price then
                TriggerClientEvent('farm:notify', src, "Insufficient funds! Price: $" .. farmConfig.price, "error")
                return
            end

            xPlayer.set('money', playerMoney - farmConfig.price)

            local defaultPass = tostring(math.random(1000, 9999))

            BuyLand(identifier, farmId, farmConfig.slots, defaultPass, function(landId)
                if landId then
                    TriggerClientEvent('farm:landBought', src, {
                        id = landId,
                        farm_id = farmId,
                        slot_count = farmConfig.slots,
                        password = defaultPass,
                        storage = {}
                    })
                    TriggerClientEvent('farm:notify', src, "Land purchased successfully! Default PIN: " .. defaultPass, "success")
                else
                    xPlayer.set('money', playerMoney)
                    TriggerClientEvent('farm:notify', src, "Error purchasing land!", "error")
                end
            end)
        end)
    end)
end)

RegisterNetEvent('farm:enterFarm')
AddEventHandler('farm:enterFarm', function(farmId, password)
    local src = source
    local identifier = GetPlayerIdentifier(src, 0)

    GetPlayerLand(identifier, farmId, function(land)
        if not land then
            TriggerClientEvent('farm:notify', src, "You don't own any land in this farm!", "error")
            TriggerClientEvent('farm:enterResult', src, false, nil)
            return
        end

        if land.password ~= password then
            TriggerClientEvent('farm:notify', src, "Incorrect PIN!", "error")
            TriggerClientEvent('farm:enterResult', src, false, nil)
            return
        end

        GetLandPlants(land.id, function(plants)
            local storage = {}
            local ok, decoded = pcall(json.decode, land.storage or '{}')
            if ok then storage = decoded end

            TriggerClientEvent('farm:enterResult', src, true, {
                land = land,
                plants = plants,
                storage = storage,
            })
            TriggerClientEvent('farm:notify', src, "Welcome to your farm!", "success")
        end)
    end)
end)

RegisterNetEvent('farm:changePassword')
AddEventHandler('farm:changePassword', function(landId, oldPass, newPass)
    local src = source
    local identifier = GetPlayerIdentifier(src, 0)

    if not newPass or #newPass < 4 or #newPass > 20 then
        TriggerClientEvent('farm:notify', src, "PIN must be between 4 and 20 characters!", "warning")
        return
    end

    MySQL.Async.fetchAll(
        "SELECT * FROM farm_lands WHERE id = @id AND identifier = @ident",
        {['@id'] = landId, ['@ident'] = identifier},
        function(result)
            if not result or #result == 0 then
                TriggerClientEvent('farm:notify', src, "Land not found or not owned by you!", "error")
                return
            end

            local land = result[1]
            if land.password ~= oldPass then
                TriggerClientEvent('farm:notify', src, "Current PIN is incorrect!", "error")
                return
            end

            UpdateLandPassword(landId, newPass, function(success)
                if success then
                    TriggerClientEvent('farm:notify', src, "PIN updated successfully!", "success")
                    TriggerClientEvent('farm:passwordChanged', src, newPass)
                else
                    TriggerClientEvent('farm:notify', src, "Error updating PIN!", "error")
                end
            end)
        end
    )
end)

RegisterNetEvent('farm:getStorage')
AddEventHandler('farm:getStorage', function(landId)
    local src = source
    local identifier = GetPlayerIdentifier(src, 0)

    MySQL.Async.fetchAll(
        "SELECT * FROM farm_lands WHERE id = @id AND identifier = @ident",
        {['@id'] = landId, ['@ident'] = identifier},
        function(result)
            if not result or #result == 0 then
                TriggerClientEvent('farm:notify', src, "Access denied!", "error")
                return
            end

            GetLandStorage(landId, function(storage)
                TriggerClientEvent('farm:storageData', src, storage)
            end)
        end
    )
end)

RegisterNetEvent('farm:takeFromStorage')
AddEventHandler('farm:takeFromStorage', function(landId, item, amount)
    local src = source
    local identifier = GetPlayerIdentifier(src, 0)

    MySQL.Async.fetchAll(
        "SELECT * FROM farm_lands WHERE id = @id AND identifier = @ident",
        {['@id'] = landId, ['@ident'] = identifier},
        function(result)
            if not result or #result == 0 then
                TriggerClientEvent('farm:notify', src, "Access denied!", "error")
                return
            end

            GetLandStorage(landId, function(storage)
                local current = storage[item] or 0
                if current < amount then
                    TriggerClientEvent('farm:notify', src, "Insufficient storage inventory!", "error")
                    return
                end

                storage[item] = current - amount
                if storage[item] <= 0 then storage[item] = nil end

                UpdateLandStorage(landId, storage, function(ok)
                    if ok then
                        TriggerClientEvent('farm:updateStorage', src, storage)
                        TriggerClientEvent('farm:notify', src, amount .. " item(s) retrieved from storage!", "success")
                    end
                end)
            end)
        end
    )
end)

RegisterNetEvent('farm:getMyLand')
AddEventHandler('farm:getMyLand', function(farmId)
    local src = source
    local identifier = GetPlayerIdentifier(src, 0)

    GetPlayerLand(identifier, farmId, function(land)
        TriggerClientEvent('farm:myLandData', src, land)
    end)
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(3600000) -- 1 Hour
        DeleteExpiredPlants(function(count)
            if count > 0 then
                LoadAllPlants()
            end
        end)
    end
end)

print("^2[FarmScript]^7 Server script loaded successfully!")