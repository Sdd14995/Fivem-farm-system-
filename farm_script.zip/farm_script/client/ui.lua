AddEventHandler('onClientResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        Citizen.Wait(1000)
        SendNUIMessage({
            type = "setConfig",
            plants = Config.Plants,
            farms = (function()
                local farmList = {}
                for id, farm in pairs(Config.Farms) do
                    table.insert(farmList, {
                        id = id,
                        name = farm.name,
                        slots = farm.slots,
                        price = farm.price,
                    })
                end
                table.sort(farmList, function(a, b) return a.id < b.id end)
                return farmList
            end)(),
        })
    end
end)
