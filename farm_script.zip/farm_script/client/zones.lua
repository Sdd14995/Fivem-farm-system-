local farmBlips = {}
local farmZones = {}

Citizen.CreateThread(function()
    for farmId, farm in pairs(Config.Farms) do
        local blip = AddBlipForCoord(farm.enterCoords.x, farm.enterCoords.y, farm.enterCoords.z)
        SetBlipSprite(blip, farm.blipSprite)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, 0.9)
        SetBlipColour(blip, farm.blipColor)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(farm.name .. " ($" .. farm.price .. ")")
        EndTextCommandSetBlipName(blip)
        farmBlips[farmId] = blip
    end
end)

Citizen.CreateThread(function()
    while true do
        local sleep = 1000
        local playerCoords = GetEntityCoords(PlayerPedId())

        for farmId, farm in pairs(Config.Farms) do
            local dist = #(playerCoords - farm.enterCoords)

            if dist < 30.0 then
                sleep = 0

                if dist < 3.0 then
                    DrawText3D(farm.enterCoords.x, farm.enterCoords.y, farm.enterCoords.z + 1.5,
                        "~g~[E]~w~ Enter " .. farm.name .. "\n~y~Price: $" .. FormatMoney(farm.price)
                    )

                    if IsControlJustPressed(0, 38) then -- E
                        TriggerEvent('farm:openFarmMenu', farmId)
                    end
                end
            end
        end

        Citizen.Wait(sleep)
    end
end)

function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local px, py, pz = table.unpack(GetGameplayCamCoords())
    local dist = #(vector3(px, py, pz) - vector3(x, y, z))
    local scale = (1 / dist) * 2
    local fov = (1 / GetGameplayCamFov()) * 100
    scale = scale * fov

    if onScreen then
        SetTextScale(0.0, scale)
        SetTextFont(0)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)

        local factor = (string.len(text)) / 370
        DrawRect(_x, _y + 0.0125, 0.030 + factor, 0.030, 0, 0, 0, 75)
    end
end

function FormatMoney(amount)
    local formatted = tostring(amount)
    local result = ""
    local count = 0
    for i = #formatted, 1, -1 do
        if count > 0 and count % 3 == 0 then
            result = "," .. result
        end
        result = formatted:sub(i, i) .. result
        count = count + 1
    end
    return result
end