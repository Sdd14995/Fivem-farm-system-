local currentFarm = nil
local myLandData = nil 
local activePlants = {} 
local plantProps = {} 
local inFarm = false
local farmTractor = nil
local nearPlant = nil 

RegisterNetEvent('farm:syncPlants')
AddEventHandler('farm:syncPlants', function(plants)
    activePlants = plants or {}
    ClearAllPlantProps()
    for plantId, plant in pairs(activePlants) do
        SpawnPlantProp(plant)
    end
end)

RegisterNetEvent('farm:plantedSeed')
AddEventHandler('farm:plantedSeed', function(plantData)
    activePlants[plantData.id] = plantData
    SpawnPlantProp(plantData)
end)

RegisterNetEvent('farm:plantWatered')
AddEventHandler('farm:plantWatered', function(plantId, wateredAt)
    if activePlants[plantId] then
        activePlants[plantId].watered = true
        activePlants[plantId].watered_at = wateredAt
    end
end)

RegisterNetEvent('farm:updateGrowth')
AddEventHandler('farm:updateGrowth', function(updates)
    for _, update in ipairs(updates) do
        if activePlants[update.id] then
            activePlants[update.id].grow_progress = update.progress
            if update.progress >= 100 then
                UpdatePlantPropGrown(update.id)
            end
        end
    end
end)

RegisterNetEvent('farm:plantHarvested')
AddEventHandler('farm:plantHarvested', function(plantId)
    activePlants[plantId] = nil
    RemovePlantProp(plantId)
end)

RegisterNetEvent('farm:plantUprooted')
AddEventHandler('farm:plantUprooted', function(plantId)
    activePlants[plantId] = nil
    RemovePlantProp(plantId)
end)

RegisterNetEvent('farm:enterResult')
AddEventHandler('farm:enterResult', function(success, data)
    if success and data then
        inFarm = true
        myLandData = data.land
        SendNUIMessage({
            type = "openFarm",
            farm = Config.Farms[data.land.farm_id],
            land = data.land,
            plants = data.plants,
            storage = data.storage,
        })
        SetNuiFocus(true, true)
    end
end)

RegisterNetEvent('farm:landBought')
AddEventHandler('farm:landBought', function(landData)
    myLandData = landData
    SendNUIMessage({
        type = "landBought",
        land = landData,
    })
end)

RegisterNetEvent('farm:updateStorage')
AddEventHandler('farm:updateStorage', function(storage)
    SendNUIMessage({
        type = "updateStorage",
        storage = storage,
    })
end)

RegisterNetEvent('farm:notify')
AddEventHandler('farm:notify', function(msg, ntype)
    ShowNotification(msg, ntype)
end)

RegisterNetEvent('farm:passwordChanged')
AddEventHandler('farm:passwordChanged', function(newPass)
    if myLandData then
        myLandData.password = newPass
    end
end)

RegisterNetEvent('farm:myLandData')
AddEventHandler('farm:myLandData', function(land)
    myLandData = land
end)

function SpawnPlantProp(plantData)
    local plantConfig = Config.Plants[plantData.plant_type]
    if not plantConfig then return end

    local propName = plantData.grow_progress >= 100 and plantConfig.prop_grown or plantConfig.prop
    local coords = plantData.coords

    local modelHash = GetHashKey(propName)
    RequestModel(modelHash)
    local timeout = 0
    while not HasModelLoaded(modelHash) and timeout < 100 do
        Citizen.Wait(50)
        timeout = timeout + 1
    end

    if HasModelLoaded(modelHash) then
        local prop = CreateObjectNoOffset(modelHash, coords.x, coords.y, coords.z, false, false, false)
        SetEntityCollision(prop, false, false)
        FreezeEntityPosition(prop, true)
        plantProps[plantData.id] = prop
    end
end

function RemovePlantProp(plantId)
    if plantProps[plantId] then
        DeleteObject(plantProps[plantId])
        plantProps[plantId] = nil
    end
end

function UpdatePlantPropGrown(plantId)
    local plant = activePlants[plantId]
    if not plant then return end

    RemovePlantProp(plantId)
    SpawnPlantProp(plant)
end

function ClearAllPlantProps()
    for plantId, prop in pairs(plantProps) do
        if DoesEntityExist(prop) then
            DeleteObject(prop)
        end
    end
    plantProps = {}
end

local isWatering = false
local isHarvesting = false
local isUprooting = false

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        if not inFarm or not myLandData then
            Citizen.Wait(500)
            goto continue
        end

        local playerCoords = GetEntityCoords(PlayerPedId())
        nearPlant = nil

        for plantId, plant in pairs(activePlants) do
            if plant.land_id ~= myLandData.id then goto nextPlant end

            local plantCoords = vector3(plant.coords.x, plant.coords.y, plant.coords.z)
            local dist = #(playerCoords - plantCoords)

            if dist < Config.InteractionDistance then
                nearPlant = plant
                local progress = math.floor(plant.grow_progress or 0)
                local r, g, b = GetGrowthColor(progress)

                if progress >= 100 then
                    DrawText3D(plant.coords.x, plant.coords.y, plant.coords.z + 1.2,
                        "~g~Ready to harvest!\n~w~[E] Harvest | [G] Remove"
                    )
                    DrawProgressBar3D(plant.coords.x, plant.coords.y, plant.coords.z + 0.8, 100, 0, 200, 0)
                elseif not plant.watered then
                    DrawText3D(plant.coords.x, plant.coords.y, plant.coords.z + 1.2,
                        "~b~Needs water!\n~w~[E] Water | [G] Remove"
                    )
                    DrawProgressBar3D(plant.coords.x, plant.coords.y, plant.coords.z + 0.8, 0, 100, 180, 0)
                else
                    DrawText3D(plant.coords.x, plant.coords.y, plant.coords.z + 1.2,
                        "~y~Growing: " .. progress .. "%%\n~w~[G] Remove"
                    )
                    DrawProgressBar3D(plant.coords.x, plant.coords.y, plant.coords.z + 0.8, progress, r, g, b)
                end

                if IsControlJustPressed(0, 38) and not isWatering and not isHarvesting then -- E
                    if not plant.watered then
                        StartWatering(plantId)
                    elseif progress >= 100 then
                        StartHarvesting(plantId)
                    end
                end

                if IsControlJustPressed(0, 47) and not isUprooting then -- G
                    StartUprooting(plantId)
                end

                break
            end
            ::nextPlant::
        end

        ::continue::
    end
end)

function StartWatering(plantId)
    isWatering = true
    ShowProgressBar("Watering plant...", Config.WateringTime)

    Citizen.SetTimeout(Config.WateringTime, function()
        isWatering = false
        if nearPlant and nearPlant.id == plantId then
            TriggerServerEvent('farm:waterPlant', plantId)
        end
    end)
end

function StartHarvesting(plantId)
    isHarvesting = true
    ShowProgressBar("Harvesting crop...", Config.HarvestTime)

    Citizen.SetTimeout(Config.HarvestTime, function()
        isHarvesting = false
        if nearPlant and nearPlant.id == plantId then
            TriggerServerEvent('farm:harvestPlant', plantId)
        end
    end)
end

function StartUprooting(plantId)
    isUprooting = true
    ShowProgressBar("Removing plant...", Config.UprootTime)

    Citizen.SetTimeout(Config.UprootTime, function()
        isUprooting = false
        TriggerServerEvent('farm:uprootPlant', plantId)
    end)
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)

        if not inFarm or not myLandData then goto continue end

        local farmConfig = Config.Farms[myLandData.farm_id]
        if not farmConfig then goto continue end

        if not farmTractor or not DoesEntityExist(farmTractor) then
            local model = GetHashKey(Config.TractorModel)
            RequestModel(model)
            local t = 0
            while not HasModelLoaded(model) and t < 100 do
                Citizen.Wait(50)
                t = t + 1
            end

            local tc = farmConfig.tractorCoords
            farmTractor = CreateVehicle(model, tc.x, tc.y, tc.z, tc.w, true, false)
            SetEntityAsMissionEntity(farmTractor, true, true)
        end

        local ped = PlayerPedId()
        if IsPedInVehicle(ped, farmTractor, false) then
            ExitFarm()
        end

        ::continue::
    end
end)

function ExitFarm()
    if not inFarm then return end
    inFarm = false

    if farmTractor and DoesEntityExist(farmTractor) then
        TaskLeaveVehicle(PlayerPedId(), farmTractor, 0)
        Citizen.Wait(1000)
        SetEntityAsMissionEntity(farmTractor, false, true)
        DeleteVehicle(farmTractor)
        farmTractor = nil
    end

    myLandData = nil
    ShowNotification("You left the farm.", "info")
    TriggerEvent('farm:leftFarm')
end

RegisterNetEvent('farm:openFarmMenu')
AddEventHandler('farm:openFarmMenu', function(farmId)
    currentFarm = farmId
    local farmConfig = Config.Farms[farmId]

    TriggerServerEvent('farm:getMyLand', farmId)

    SendNUIMessage({
        type = "openMenu",
        farmId = farmId,
        farmName = farmConfig.name,
        farmPrice = farmConfig.price,
        farmSlots = farmConfig.slots,
        plants = Config.Plants,
    })
    SetNuiFocus(true, true)
end)

RegisterNUICallback('buyLand', function(data, cb)
    TriggerServerEvent('farm:buyLand', data.farmId)
    cb({})
end)

RegisterNUICallback('enterFarm', function(data, cb)
    TriggerServerEvent('farm:enterFarm', data.farmId, data.password)
    cb({})
end)

RegisterNUICallback('changePassword', function(data, cb)
    if myLandData then
        TriggerServerEvent('farm:changePassword', myLandData.id, data.oldPass, data.newPass)
    end
    cb({})
end)

RegisterNUICallback('getStorage', function(data, cb)
    if myLandData then
        TriggerServerEvent('farm:getStorage', myLandData.id)
    end
    cb({})
end)

RegisterNUICallback('takeFromStorage', function(data, cb)
    if myLandData then
        TriggerServerEvent('farm:takeFromStorage', myLandData.id, data.item, data.amount)
    end
    cb({})
end)

RegisterNUICallback('closeMenu', function(data, cb)
    SetNuiFocus(false, false)
    currentFarm = nil
    cb({})
end)

RegisterNUICallback('plantSeed', function(data, cb)
    if myLandData then
        local farmConfig = Config.Farms[myLandData.farm_id]
        local usedSlots = {}
        for _, plant in pairs(activePlants) do
            if plant.land_id == myLandData.id then
                usedSlots[plant.slot_index] = true
            end
        end

        for i, coord in ipairs(farmConfig.landCoords) do
            if not usedSlots[i] then
                TriggerServerEvent('farm:plantSeed', myLandData.id, i, data.plantType,
                    {x = coord.x, y = coord.y, z = coord.z})
                cb({success = true, slotIndex = i})
                return
            end
        end
        cb({success = false, msg = "No empty slots available!"})
    else
        cb({success = false, msg = "Enter the farm first!"})
    end
end)

function ShowProgressBar(label, duration)
    SendNUIMessage({
        type = "progressBar",
        label = label,
        duration = duration,
    })
end

function GetGrowthColor(progress)
    if progress >= 100 then return 0, 255, 50 end
    if progress >= 75 then return 100, 255, 100 end
    if progress >= 50 then return 200, 255, 0 end
    if progress >= 25 then return 255, 200, 0 end
    return 255, 100, 100
end

function DrawProgressBar3D(x, y, z, progress, r, g, b)
    local onScreen, sx, sy = World3dToScreen2d(x, y, z)
    if onScreen then
        local width = 0.05
        local height = 0.008
        local fillWidth = (width * progress) / 100

        DrawRect(sx, sy, width, height, 0, 0, 0, 180)
        if progress > 0 then
            DrawRect(sx - (width/2) + (fillWidth/2), sy, fillWidth, height, r, g, b, 220)
        end
    end
end

function ShowNotification(msg, ntype)
    local colors = {
        success = "~g~",
        error = "~r~",
        warning = "~y~",
        info = "~b~",
    }
    local prefix = colors[ntype] or "~w~"
    SetNotificationTextEntry("STRING")
    AddTextComponentString(prefix .. msg)
    DrawNotification(false, true)
end

Citizen.CreateThread(function()
    Citizen.Wait(3000)
    TriggerServerEvent('farm:requestPlants')
end)

print("^2[FarmScript]^7 Client script loaded!")